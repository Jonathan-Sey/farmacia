
<?php $__env->startSection('titulo', 'Reporte de ventas'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <a href="<?php echo e(route('Reporte_ventas.filtrarPorFecha')); ?>">
            <div class="w-auto h-40 bg-slate-50 rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3  ">
                    <div class="flex flex-col items-center">
                        <i class='bx bxs-package text-7xl lg:text-6xl md:text-6xl sm:text-6xl' ></i>
                        <p class="uppercase text-lg font-bold">reporte por fecha</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                       
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('sucursales.index')); ?>">
            <div class="w-auto h-40 bg-slate-50 rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2  sm:p-3 ">
                    <div class="flex flex-col items-center">
                        <i class='bx bxs-building text-7xl lg:text-6xl  sm:text-6xl' ></i>
                        <p class="uppercase text-lg font-bold">reporte por sucursales</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                    
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('compras.index')); ?>">
            <div class="w-auto h-40 bg-slate-50 rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2  sm:p-3 ">
                    <div class="flex flex-col items-center">
                        <i class='fa-solid fa-cart-shopping text-7xl lg:text-6xl sm:text-6xl' ></i>
                        <p class="uppercase text-lg font-bold">reporte por usuario </p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('ventas.index')); ?>">
            <div class="w-auto h-40 bg-slate-50 rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3">
                    <div class="flex flex-col items-center">
                        <i class='fa-solid fa-bag-shopping text-7xl lg:text-6xl sm:text-6xl' ></i>
                        <p class="uppercase text-lg font-bold">reporte por maquina</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        
                    </div>
            </div>
        </a>

    </div>


    <div class="grid gap-5 grid-cols-1 items-start mb-8">
        <div class="max-h-[800px] overflow-x-auto bg-white p-2 rounded-lg shadow-lg text-center">
            <div class="md:flex md:flex-row md:gap-3 lg:justify-between p-3 pb-8 sm:flex sm:flex-col sm:gap-5 sm:justify-center">
                <h2 class="text-2xl m-2 font-bold sm:grid sm:grid-cols-1 ">Ventas por mes</h2>
                    <div>
                            <label for="sucursalSelector" class="uppercase block text-sm font-medium text-gray-900">Sucursal</label>
                            <select
                                class="select2-sucursal block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"

                                id="sucursalSelector"
                                >
                                <option value="">Todo</option>
                                <?php $__currentLoopData = $nombreSucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?> - <?php echo e($sucursal->ubicacion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                <input type="month" id="mesAñoSelector" value="<?php echo e(date('Y-m')); ?>">
            </div>
            <div id="ventasMes">

            </div>
        </div>
    </div>

<?php $__env->startPush('js'); ?>

        <script src="https://code.highcharts.com/highcharts.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>
        <script src="https://code.highcharts.com/modules/export-data.js"></script>
        <script src="https://code.highcharts.com/modules/accessibility.js"></script>
        <script src="https://code.highcharts.com/modules/offline-exporting.js"></script>

        <script>
        // creacion de arreglo para iterar los meses pero con su respectico nombre
        const Meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

        function reformarChart(diasMes, ventasPorDia, totalGeneral, mes, año){
            // diseño de la tabla
            let totalVentas = round(totalGeneral);
            Highcharts.chart('ventasMes', {
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Ventas de '+ Meses[mes - 1] + ' del '+ año
                },
                subtitle: {
                    text: 'Total Ventas: Q.' + totalVentas
                },
                xAxis: {
                    categories: diasMes,
                    accessibility: {
                        description: 'Dias del mes'
                    }
                },
                yAxis: {
                    title: {
                        text: 'Total de ingresos por día'
                    },
                    labels: {
                        format: '{value}'
                    }
                },
                tooltip: {
                    crosshairs: true,
                    shared: true
                },
                plotOptions: {
                    line: {
                        dataLabels:{
                            enabled:true
                        },
                        marker: {
                            radius: 4,
                            lineColor: '#666666',
                            lineWidth: 1
                        }
                    }
                },
                series: [{
                    name: 'Ventas del dia ',
                    marker: {
                        enabled: true,
                        symbol: 'circle'
                    },
                    data: ventasPorDia

                }]
            });

        }

        function fetchData() {
            var mesAño = document.getElementById('mesAñoSelector').value.split('-');
            //var mesAño = this.value.split('-'); // corecion de por split
            var año = mesAño[0];
            var mes = mesAño[1];
            var sucursal = document.getElementById('sucursalSelector').value;

            $.ajax({
                url: '<?php echo e(route("dashboard.filtrarVentas")); ?>',
                method:'GET',
                data:{
                    año: año,
                    mes: mes,
                    sucursal: sucursal,
                },
                success: function(response){
                    reformarChart(response.diasMes, response.ventasPorDia, response.totalGeneral, response.mes, response.año);
                }
            });
        }

        // Agregacion de evneto a los selectores
        document.getElementById('mesAñoSelector').addEventListener('change', fetchData);
        document.getElementById('sucursalSelector').addEventListener('change', fetchData);

        // iniciamos la grafica con los valores por default, justo lo que esta en su value
        document.addEventListener('DOMContentLoaded', function(){
            reformarChart(<?php echo json_encode($diasMes); ?>, <?php echo json_encode($ventasPorDia); ?>, '<?php echo e($totalGeneral); ?>', '<?php echo e($mes); ?>', '<?php echo e($año); ?>')
        });

          // funcion para redondear los numeros
        // funete: https://es.stackoverflow.com/questions/48958/redondear-a-dos-decimales-cuando-sea-necesario
        function round(num, decimales = 2) {
            var signo = (num >= 0 ? 1 : -1);
            num = num * signo;
            if (decimales === 0) //con 0 decimales
                return signo * Math.round(num);
            // round(x * 10 ^ decimales)
            num = num.toString().split('e');
            num = Math.round(+(num[0] + 'e' + (num[1] ? (+num[1] + decimales) : decimales)));
            // x * 10 ^ (-decimales)
            num = num.toString().split('e');
            return signo * (num[0] + 'e' + (num[1] ? (+num[1] - decimales) : -decimales));
        }

        // proceso para traducir las opciones a español
        Highcharts.setOptions({
            lang: {
            contextButtonTitle: "Menú contextual",
            downloadCSV: "Descargar archivo CSV",
            downloadJPEG: "Descargar imagen JPEG",
            downloadPDF: "Descargar documento PDF",
            downloadPNG: "Descargar imagen PNG",
            downloadSVG: "Descargar imagen vectorial SVG",
            downloadXLS: "Descargar archivo XLS",
            viewData: "Ver tabla de datos",
            hideData: "Ocultar tabla de datos",  // Traducción de "Hide data table"
            viewFullscreen: "Ver en pantalla completa",
            exitFullscreen: "Salir de pantalla completa",  // Traducción de "Exit from full screen"
            printChart: "Imprimir gráfico",
            resetZoom: "Restablecer zoom",
            resetZoomTitle: "Restablecer nivel de zoom",
            thousandsSep: ".",
            decimalPoint: ",",
            loading: "Cargando...",
            months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
            shortMonths: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
            weekdays: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
            rangeSelectorFrom: "De",
            rangeSelectorTo: "A",
            rangeSelectorZoom: "Periodo",
            }
        });
        </script>

        <script>

        </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/reportes/ventas.blade.php ENDPATH**/ ?>