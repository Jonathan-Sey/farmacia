

<?php $__env->startSection('titulo', 'Detalle de Lotes en Inventario'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <h2 class="text-xl font-bold mb-4">Lotes Originales</h2>
    <div class="overflow-x-auto">
        <table class="table table-md table-pin-rows table-pin-cols">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Número de Lote</th>
                    <th>Producto</th>
                    <th>Cantidad Original</th>
                    <th>Fecha de Vencimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php $iteracion = 0; ?>
                <?php $__currentLoopData = $lotesOriginales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $iteracion++; ?>
                <tr>
                    <th><?php echo e($iteracion); ?></th>
                    <td><?php echo e($lote->numero_lote); ?></td>
                    <td><?php echo e($lote->producto->nombre); ?></td>
                    <td><?php echo e($lote->cantidad); ?></td>
                    <td><?php echo e($lote->fecha_vencimiento); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <h2 class="text-xl font-bold mt-8 mb-4">Lotes Disponibles en Inventario</h2>
    <div class="overflow-x-auto">
        <table class="table table-md table-pin-rows table-pin-cols">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Número de Lote</th>
                    <th>Producto</th>
                    <th>Sucursal</th>
                    <th>Cantidad Disponible</th>
                    <th>Fecha de Vencimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php $iteracion = 0; ?>
                <?php $__currentLoopData = $lotesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $iteracion++; ?>
                <tr>
                    <th><?php echo e($iteracion); ?></th>
                    <td><?php echo e($inventario->lote->numero_lote); ?></td>
                    <td><?php echo e($inventario->producto->nombre); ?></td>
                    <td><?php echo e($inventario->sucursal->ubicacion); ?></td>
                    <td><?php echo e($inventario->cantidad); ?></td>
                    <td><?php echo e($inventario->lote->fecha_vencimiento); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/Inventario/show.blade.php ENDPATH**/ ?>