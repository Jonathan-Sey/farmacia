
<?php $__env->startSection('titulo','Panel'); ?>


<!--comentario-->
<?php $__env->startPush('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>



<p class="bg-gray-300 p-4 rounded-lg shadow-md max-w-max text-lg font-semibold text-white">
    Bienvenido
    <span id="user-name" class="text-black transition-all duration-300 ease-in-out">Cargando...</span>
</p>




    <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <a href="<?php echo e(route('productos.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3  ">
                    <div class="flex flex-col items-center">
                        <i class='bx bxs-package text-7xl lg:text-6xl md:text-6xl sm:text-6xl text-white' ></i>
                        <p class="uppercase text-lg font-bold text-white">Productos</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($productos); ?></p>
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('sucursales.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2  sm:p-3 ">
                    <div class="flex flex-col items-center">
                        <i class='bx bxs-building text-7xl lg:text-6xl  sm:text-6xl text-white' ></i>
                        <p class="uppercase text-lg font-bold text-white">Sucursales</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($sucursales); ?></p>
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('compras.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2  sm:p-3 ">
                    <div class="flex flex-col items-center">
                        <i class='fa-solid fa-cart-shopping text-7xl lg:text-6xl sm:text-6xl text-white' ></i>
                        <p class="uppercase text-lg font-bold text-white">Compras</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($compras); ?></p>
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('ventas.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3">
                    <div class="flex flex-col items-center">
                        <i class='fa-solid fa-bag-shopping text-7xl lg:text-6xl sm:text-6xl text-white' ></i>
                        <p class="uppercase text-lg font-bold text-white">Ventas</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($NumeroVentas); ?></p>
                    </div>
            </div>
        </a>
        <a href="<?php echo e(route('productos.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3">
                    <div class="flex flex-col items-center">
                        <i class='fa-solid fa-heart-circle-check text-7xl lg:text-6xl sm:text-6xl text-white' ></i>

                        <p class="uppercase text-lg font-bold text-white">Servicios variados</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($servicios); ?> </p>
                    </div>
            </div>

        </a>
        <a href="<?php echo e(route('medicos.index')); ?>">
            <div class="w-auto h-40 bg-[#045951] rounded-md shadow-lg grid grid-cols-2 justify-center align-middle items-center text-center sm:grid-cols-1 lg:grid-cols-1 lg:p-2 sm:p-3">
                    <div class="flex flex-col items-center ">
                        <i class='fa-solid fa-user-nurse text-7xl lg:text-6xl sm:text-6xl text-white'  ></i>

                        <p class="uppercase text-lg font-bold text-white">Médicos</p>
                    </div>
                    <div class="uppercase font-bold sm:text-5xl lg:text-6xl xl:text-7xl">
                        <p class="text-5xl sm:text-3xl font-bold lg:text-3xl text-white"><?php echo e($medicos); ?> </p>
                    </div>
            </div>

        </a>
    </div>


    <div class="grid gap-5 sm:grid-cols-1 lg:grid-cols-2 items-start mb-8">
        <div class=" max-h-[400px] overflow-x-auto bg-[#045951] p-2 rounded-lg shadow-lg text-center">
            <h2 class="text-2xl m-2 font-bold  text-white">Últimas ventas</h2>
            <table class="table table-xs table-pin-rows table-pin-cols min-w-full sm:min-w-[400px]">
                <thead>
                    <tr>
                        <th>#</th>
                        <td>Cliente</td>
                        <td>Producto</td>
                        <td>Sucursal</td>
                        <td>Total</td>
                        <td>Ver</td>
                        <th>#</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr  class="bg-white">
                        <th><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($venta->persona->nombre); ?></td>
                        <td>
                            <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($producto->nombre); ?><?php if(!$loop->last): ?>,
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($venta->sucursal->nombre); ?> - <?php echo e($venta->sucursal->ubicacion); ?></td>
                        <td><?php echo e($venta->total); ?></td>
                        <td><a href="<?php echo e(route('ventas.show', $venta->id)); ?>"><i class="fa-solid fa-eye"></i></a></td>
                        <th><?php echo e($loop->iteration); ?></th>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="max-h-[800px] overflow-x-auto bg-white p-2 rounded-lg shadow-lg text-center">
            <h2 class="text-2xl m-2 text-black">Productos más vendidos</h2>
            <div class="md:flex md:flex-row md:gap-3 lg:justify-between p-3 pb-8 sm:flex sm:flex-col sm:gap-5 sm:justify-center">
                <div>
                    <label for="sucursalSelectorProductos" class="uppercase block text-sm font-medium text-gray-900">Sucursal</label>
                    <select
                        class="select2-sucursal block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                        id="sucursalSelectorProductos"
                    >
                        <option value="">Todo</option>
                        <?php $__currentLoopData = $nombreSucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?> - <?php echo e($sucursal->ubicacion); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="month" id="mesAñoSelectorProductos" value="<?php echo e(date('Y-m')); ?>">
            </div>
            <div id="productosVendidos"></div>
        </div>
    </div>

    <div class="grid gap-5 grid-cols-1 items-start mb-8">
        <div class="max-h-[800px] overflow-x-auto bg-white p-2 rounded-lg shadow-lg text-center">
            <div class="md:flex md:flex-row md:gap-3 lg:justify-between p-3 pb-8 sm:flex sm:flex-col sm:gap-5 sm:justify-center">
                <h2 class=" text-black text-2xl m-2 font-bold sm:grid sm:grid-cols-1 ">Ventas por mes</h2>
                    <div>
                            <label for="sucursalSelector" class="uppercase block text-sm font-medium text-gray-900">Sucursal</label>
                            <select
                                class="select2-sucursal block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"

                                id="sucursalSelector"
                                >
                                <option value="">Todo</option>
                                <?php $__currentLoopData = $nombreSucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?> - <?php echo e($sucursal->ubicacion); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                <input type="month" id="mesAñoSelector" value="<?php echo e(date('Y-m')); ?>">
            </div>
            <div id="ventasMes">

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
        
        <script src="https://code.highcharts.com/highcharts.js"></script>
        <script src="https://code.highcharts.com/modules/exporting.js"></script>
        <script src="https://code.highcharts.com/modules/export-data.js"></script>
        <script src="https://code.highcharts.com/modules/accessibility.js"></script>
        <script src="https://code.highcharts.com/modules/offline-exporting.js"></script>


        <script>
        // creacion de arreglo para iterar los meses pero con su respectico nombre
        const Meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

        function reformarChart(diasMes, ventasPorDia, totalGeneral, mes, año){
            // diseño de la tabla
            let totalVentas = round(totalGeneral);
            Highcharts.chart('ventasMes', {
                chart: {
                    type: 'line'
                },
                title: {
                    text: 'Ventas de '+ Meses[mes - 1] + ' del '+ año
                },
                subtitle: {
                    text: 'Total Ventas: Q.' + totalVentas
                },
                xAxis: {
                    categories: diasMes,
                    accessibility: {
                        description: 'Días del mes'
                    }
                },
                yAxis: {
                    title: {
                        text: 'Total de ingresos por día'
                    },
                    labels: {
                        format: '{value}'
                    }
                },
                tooltip: {
                    crosshairs: true,
                    shared: true
                },
                plotOptions: {
                    line: {
                        dataLabels:{
                            enabled:true
                        },
                        marker: {
                            radius: 4,
                            lineColor: '#666666',
                            lineWidth: 1
                        }
                    }
                },
                series: [{
                    name: 'Ventas del día ',
                    marker: {
                        enabled: true,
                        symbol: 'circle'
                    },
                    data: ventasPorDia

                }]
            });

        }

        function fetchData() {
            var mesAño = document.getElementById('mesAñoSelector').value.split('-');
            //var mesAño = this.value.split('-'); // corecion de por split
            var año = mesAño[0];
            var mes = mesAño[1];
            var sucursal = document.getElementById('sucursalSelector').value;

            $.ajax({
                url: '<?php echo e(route("dashboard.filtrarVentas")); ?>',
                method:'GET',
                data:{
                    año: año,
                    mes: mes,
                    sucursal: sucursal,
                },
                success: function(response){
                    reformarChart(response.diasMes, response.ventasPorDia, response.totalGeneral, response.mes, response.año);
                }
            });
        }

        // Agregacion de evneto a los selectores
        document.getElementById('mesAñoSelector').addEventListener('change', fetchData);
        document.getElementById('sucursalSelector').addEventListener('change', fetchData);

        // iniciamos la grafica con los valores por default, justo lo que esta en su value
        document.addEventListener('DOMContentLoaded', function(){
            reformarChart(<?php echo json_encode($diasMes); ?>, <?php echo json_encode($ventasPorDia); ?>, '<?php echo e($totalGeneral); ?>', '<?php echo e($mes); ?>', '<?php echo e($año); ?>')
        });

          // funcion para redondear los numeros
        // funete: https://es.stackoverflow.com/questions/48958/redondear-a-dos-decimales-cuando-sea-necesario
        function round(num, decimales = 2) {
            var signo = (num >= 0 ? 1 : -1);
            num = num * signo;
            if (decimales === 0) //con 0 decimales
                return signo * Math.round(num);
            // round(x * 10 ^ decimales)
            num = num.toString().split('e');
            num = Math.round(+(num[0] + 'e' + (num[1] ? (+num[1] + decimales) : decimales)));
            // x * 10 ^ (-decimales)
            num = num.toString().split('e');
            return signo * (num[0] + 'e' + (num[1] ? (+num[1] - decimales) : -decimales));
        }

        // proceso para traducir las opciones a español
        Highcharts.setOptions({
            lang: {
            contextButtonTitle: "Menú contextual",
            downloadCSV: "Descargar archivo CSV",
            downloadJPEG: "Descargar imagen JPEG",
            downloadPDF: "Descargar documento PDF",
            downloadPNG: "Descargar imagen PNG",
            downloadSVG: "Descargar imagen vectorial SVG",
            downloadXLS: "Descargar archivo XLS",
            viewData: "Ver tabla de datos",
            hideData: "Ocultar tabla de datos",  // Traducción de "Hide data table"
            viewFullscreen: "Ver en pantalla completa",
            exitFullscreen: "Salir de pantalla completa",  // Traducción de "Exit from full screen"
            printChart: "Imprimir gráfico",
            resetZoom: "Restablecer zoom",
            resetZoomTitle: "Restablecer nivel de zoom",
            thousandsSep: ".",
            decimalPoint: ",",
            loading: "Cargando...",
            months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
            shortMonths: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
            weekdays: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
            rangeSelectorFrom: "De",
            rangeSelectorTo: "A",
            rangeSelectorZoom: "Periodo",
            }
        });
        </script>

        <script>
function fetchProductosMasVendidos() {
    var mesAño = document.getElementById('mesAñoSelectorProductos').value.split('-');
    var año = mesAño[0];
    var mes = mesAño[1];
    var sucursal = document.getElementById('sucursalSelectorProductos').value;

    $.ajax({
        url: '<?php echo e(route("dashboard.productosMasVendidos")); ?>',
        method: 'GET',
        data: {
            año: año,
            mes: mes,
            sucursal: sucursal,
        },
        success: function(response) {
            actualizarGraficaProductosVendidos(response.productosVendidos, mes, año);
        }
    });
}

function actualizarGraficaProductosVendidos(productosVendidos, mes, año) {
    Highcharts.chart('productosVendidos', {
        chart: {
            type: 'pie'
        },
        title: {
            text: 'Productos más vendidos en ' + Meses[mes - 1] + ' del ' + año
        },
        tooltip: {
            valueSuffix: '%',
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: [{
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y} Und',
                    style: {
                        color: '#000000', // Color del texto en negro
                        fontSize: '12px'
                    }
                    //format: '{point.name}: {point.percentage:.1f}%',
                }, {
                    enabled: true,
                    distance: -40,
                    format: '{point.percentage:.1f}%',
                    style: {
                        fontSize: '1.2em',
                        color: '#FFF',
                        fontSize: '15px',
                        textOutline: 'none',
                        opacity: 1
                    },
                    filter: {
                        operator: '>',
                        property: 'percentage',
                        value: 10
                    }

                }]
            }
        },
        series: [{
            name: 'Productos',
            colorByPoint: true,
            data: productosVendidos.map(producto => ({
                name: producto.nombre,
                y: producto.cantidad
            }))
        }]
    });
}

// Agregar evento a los selectores
document.getElementById('mesAñoSelectorProductos').addEventListener('change', function() {
    fetchData();
    fetchProductosMasVendidos();
});

document.getElementById('sucursalSelectorProductos').addEventListener('change', function() {
    fetchData();
    fetchProductosMasVendidos();
});

// Iniciar la gráfica con los valores por defecto
document.addEventListener('DOMContentLoaded', function() {
    fetchProductosMasVendidos();
});
        </script>


<?php $__env->stopPush(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/dashboard/index.blade.php ENDPATH**/ ?>