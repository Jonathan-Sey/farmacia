
<?php $__env->startSection('titulo','Detalle venta'); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Venta</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->id); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Vendedor</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->usuario->name); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Cliente</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->persona->nombre); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Sucursal</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->sucursal->nombre); ?> - <?php echo e($venta->sucursal->ubicacion); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Fecha y hora</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->created_at); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Impuesto</p>
    </div>
    <div class="md:col-span-2">
      <p id="impuesto"  class="p-2 text-center font-semibold " ><?php echo e($venta->impuesto); ?></p>
    </div>
</div>

<div class="card bg-base-100 w-full shadow-lg md:grid md:grid-cols-3 mb-5">
    <div class="card-body items-center p-2 bg-slate-200 rounded-t-xl md:rounded-xl md:col-span-1">
      <p class="card-title font">Total</p>
    </div>
    <div class="md:col-span-2">
      <p class="p-2 text-center font-semibold " ><?php echo e($venta->total); ?></p>
    </div>
</div>

<div class="mt-5">
    <h2 class="text-center m-5 font-bold text-lg">Detalle Venta</h2>
    <div class="overflow-x-auto">
        <table id="tabla-productos" class="table table-md table-pin-rows table-pin-cols">
          <thead>
            <tr>
              <th></th>
              <td>Producto</td>
              <td>Cantidad</td>
              <td>Precio</td>
              <td>SubTotal</td>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $venta->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th></th>
                <td class="bg-white"><?php echo e($producto->nombre); ?> </td>
                <td class="bg-white"><?php echo e($producto->pivot->cantidad); ?> </td>
                <td class="bg-white"><?php echo e($producto->precio_venta); ?> </td>
                <td class="subTotal bg-white"><?php echo e($producto->pivot->cantidad * $producto->precio_venta); ?></td>
                <th></th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
                <th></th>
                <td class="text-sm font-black">SUMA:  <span id="suma" class="font-black">0</span></td>
                <td class="text-sm font-black">IVA: <span id="iva" class="font-black">0</span></td>
                <td class="text-sm font-black"><input type="hidden" name="total" value="0" id="inputTotal"> TOTAL:  <span id="total" class="font-black">0</span></td>
                <td class="text-sm font-black"></td>
                <th></th>
            </tr>
          </tfoot>
        </table>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>

<script>
    $(document).ready(function(){
        calcularValores();
    });
    function calcularValores() {
    let suma = 0;
    let subTotal = document.getElementsByClassName('subTotal');
    let impuesto = parseFloat(document.getElementById('impuesto').innerHTML) || 0;

    for(let i = 0; i < subTotal.length; i++) {
        suma += parseFloat(subTotal[i].innerHTML);
    }

    let ivaCalculado = Math.round((suma * impuesto) / 100);
    let totalCalculado = Math.round(suma + ivaCalculado);

    $('#suma').html(Math.round(suma));
    $('#iva').html(ivaCalculado);
    $('#total').html(totalCalculado);
    $('#inputTotal').val(totalCalculado);
}

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/venta/show.blade.php ENDPATH**/ ?>