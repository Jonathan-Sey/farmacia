
<footer class="text-center p-5 text-gray-500 font-bold uppercase">
    Farmacia - Todo los derechos reservados {{ now()->year}}
    {{-- helpers --}}
</footer>
