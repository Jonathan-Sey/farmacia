
<?php $__env->startSection('titulo', 'Crear Persona'); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .compact-select {
        max-width: 200px;
        margin-bottom: 1.5rem;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
<div class="flex justify-center items-center mx-3">
    <div class="bg-white p-5 rounded-xl shadow-lg w-full max-w-3xl mb-10">
        <form action="<?php echo e(route('personas.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div id="usuario"></div>
            <div class="border-b border-gray-900/10 pb-12">

                <!-- Selector de Rol -->
                <div class="mb-6">
                    <label for="rol" class="uppercase block text-sm font-medium text-gray-900 mb-1">Tipo de Persona</label>
                    <select name="rol" id="rol" required class="compact-select block rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm">
                        <option value="1" <?php echo e(old('rol') == 1 ? 'selected' : ''); ?>>Cliente</option>
                        <option value="2" <?php echo e(old('rol') == 2 ? 'selected' : ''); ?>>Paciente</option>
                    </select>
                </div>

                <!-- Datos Básicos -->
                <div class="mt-2 mb-5 grid grid-cols-1 gap-5">
                    <!-- Nombre -->
                    <div>
                        <label for="nombre" class="uppercase block text-sm font-medium text-gray-900">Nombre</label>
                        <input
                            type="text"
                            name="nombre"
                            id="nombre"
                            required
                            autocomplete="given-name"
                            placeholder="Nombre completo"
                            class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                            value="<?php echo e(old('nombre')); ?>">
                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div role="alert" class="alert alert-error mt-4 p-2">
                            <span class="text-white font-bold"><?php echo e($message); ?></span>
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Apellidos (solo para pacientes) -->
                    <div id="apellidos-section" class="hidden grid grid-cols-1 gap-5 md:grid-cols-2">
                        <div>
                            <label for="apellido_paterno" class="uppercase block text-sm font-medium text-gray-900">Apellido Paterno</label>
                            <input
                                type="text"
                                name="apellido_paterno"
                                id="apellido_paterno"
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('apellido_paterno')); ?>">
                        </div>

                        <div>
                            <label for="apellido_materno" class="uppercase block text-sm font-medium text-gray-900">Apellido Materno</label>
                            <input
                                type="text"
                                name="apellido_materno"
                                id="apellido_materno"
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('apellido_materno')); ?>">
                        </div>
                    </div>

                    <!-- Información de Contacto -->
                    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
                        <div>
                            <label for="nit" class="uppercase block text-sm font-medium text-gray-900">NIT</label>
                            <input
                                type="text"
                                name="nit"
                                id="nit"
                                required
                                placeholder="NIT"
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('nit')); ?>">
                            <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div role="alert" class="alert alert-error mt-4 p-2">
                                <span class="text-white font-bold"><?php echo e($message); ?></span>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="text-sm font-medium text-gray-700">DPI *</label>
                                <input type="text" name="dpi" value="<?php echo e(old('dpi', $fichaMedica->DPI ?? '')); ?>"
                                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                                <?php $__errorArgs = ['dpi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label for="telefono" class="uppercase block text-sm font-medium text-gray-900">Teléfono</label>
                            <input
                                type="text"
                                name="telefono"
                                id="telefono"
                                required
                                placeholder="Teléfono"
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('telefono')); ?>">
                            <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div role="alert" class="alert alert-error mt-4 p-2">
                                <span class="text-white font-bold"><?php echo e($message); ?></span>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Fecha de Nacimiento -->
                    <div class="grid grid-cols-1">
                        <div>
                            <label for="fecha_nacimiento" class="uppercase block text-sm font-medium text-gray-900">Fecha Nacimiento</label>
                            <input
                                type="date"
                                name="fecha_nacimiento"
                                id="fecha_nacimiento"
                                required
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('fecha_nacimiento')); ?>">
                            <?php $__errorArgs = ['fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div role="alert" class="alert alert-error mt-4 p-2">
                                <span class="text-white font-bold"><?php echo e($message); ?></span>
                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Sección específica para Pacientes -->
                <div id="ficha_medica" class="hidden mt-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-5 border-b pb-2">Información Médica</h3>

                    <div class="grid grid-cols-1 gap-5 md:grid-cols-3">
                        <div>
                            <label for="sexo" class="uppercase block text-sm font-medium text-gray-900">Sexo</label>
                            <select name="sexo" id="sexo" class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm">
                                <option value="Hombre" <?php echo e(old('sexo') == 'Hombre' ? 'selected' : ''); ?>>Hombre</option>
                                <option value="Mujer" <?php echo e(old('sexo') == 'Mujer' ? 'selected' : ''); ?>>Mujer</option>
                            </select>
                        </div>

                        <div>
                            <label for="tipo_sangre" class="uppercase block text-sm font-medium text-gray-900">Tipo de Sangre</label>
                            <select name="tipo_sangre" id="tipo_sangre" class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm">
                                <option value="" disabled selected>Selecciona un tipo</option>
                                <option value="O+" <?php echo e(old('tipo_sangre') == 'O+' ? 'selected' : ''); ?>>O+</option>
                                <option value="O-" <?php echo e(old('tipo_sangre') == 'O-' ? 'selected' : ''); ?>>O-</option>
                                <option value="A+" <?php echo e(old('tipo_sangre') == 'A+' ? 'selected' : ''); ?>>A+</option>
                                <option value="A-" <?php echo e(old('tipo_sangre') == 'A-' ? 'selected' : ''); ?>>A-</option>
                                <option value="B+" <?php echo e(old('tipo_sangre') == 'B+' ? 'selected' : ''); ?>>B+</option>
                                <option value="B-" <?php echo e(old('tipo_sangre') == 'B-' ? 'selected' : ''); ?>>B-</option>
                                <option value="AB+" <?php echo e(old('tipo_sangre') == 'AB+' ? 'selected' : ''); ?>>AB+</option>
                                <option value="AB-" <?php echo e(old('tipo_sangre') == 'AB-' ? 'selected' : ''); ?>>AB-</option>
                            </select>
                        </div>

                        <div>
                            <label for="habla_lengua" class="uppercase block text-sm font-medium text-gray-900">Habla Lengua</label>
                            <select name="habla_lengua" id="habla_lengua" class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm">
                                <option value="Sí" <?php echo e(old('habla_lengua') == 'Sí' ? 'selected' : ''); ?>>Sí</option>
                                <option value="No" <?php echo e(old('habla_lengua') == 'No' ? 'selected' : ''); ?>>No</option>
                            </select>
                        </div>
                    </div>

                    <div class="mt-5 grid grid-cols-1">
                        <div>
                            <label for="direccion" class="uppercase block text-sm font-medium text-gray-900">Dirección</label>
                            <input
                                type="text"
                                name="direccion"
                                id="direccion"
                                class="block w-full rounded-md bg-white px-3 py-1.5 text-base text-gray-900 outline outline-1 -outline-offset-1 outline-gray-300 placeholder:text-gray-400 focus:outline focus:outline-2 focus:-outline-offset-2 focus:outline-indigo-600 sm:text-sm"
                                value="<?php echo e(old('direccion')); ?>">
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-6 flex items-center justify-end gap-x-6">
                <a href="<?php echo e(route('personas.index')); ?>">
                    <button type="button" class="text-sm font-semibold text-gray-900">Cancelar</button>
                </a>
                <button type="submit" class="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-indigo-600">Guardar</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="/js/obtenerUsuario.js"></script>
<script>
    $(document).ready(function() {
        // Manejar cambio de rol
        $('#rol').change(function() {
            if ($(this).val() == 2) {
                // Mostrar apellidos y ficha médica
                $('#apellidos-section, #ficha_medica').removeClass('hidden');
                // Hacer requeridos los campos adicionales
                $('#apellido_paterno, #apellido_materno').prop('required', true);
                $('#ficha_medica input, #ficha_medica select').prop('required', true);
            } else {
                // Ocultar secciones adicionales
                $('#apellidos-section, #ficha_medica').addClass('hidden');
                // Quitar requeridos
                $('#apellido_paterno, #apellido_materno').prop('required', false);
                $('#ficha_medica input, #ficha_medica select').prop('required', false);
            }
        }).trigger('change');

        // Asegurar envío del formulario
        $('form').submit(function(e) {
            if ($('#rol').val() == 1) {
                $('#apellidos-section, #ficha_medica').find('input, select').prop('disabled', true);
            }
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if($errors->has('dpi')): ?>
<script>
  Swal.fire({
    icon: 'error',
    title: 'Error',
    text: '<?php echo e($errors->first('dpi')); ?>',
  });
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/persona/create.blade.php ENDPATH**/ ?>