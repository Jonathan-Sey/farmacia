<div id="tabla-dinamica" class="overflow-x-auto shadow-md rounded-lg p-4 bg-white">
    <table id="example" class="ui celled table hover min-w-full divide-y divide-gray-200 text-sm">
        <?php echo e($thead); ?>

        <?php echo e($tbody); ?>

    </table>
</div>
<?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/components/data-table.blade.php ENDPATH**/ ?>