

<?php $__env->startSection('titulo','Productos vencidos'); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.2.0/css/buttons.dataTables.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.3/css/responsive.bootstrap5.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
<?php if (isset($component)) { $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DataTable::class, []); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('thead', null, []); ?> 
        <thead class="text-white font-bold">
            <tr class="bg-slate-600">
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Código</th>
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Producto</th>
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Imagen</th>
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Sucursal</th>
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Cantidad</th>
                <th class="px-6 py-3 text-left font-medium uppercase tracking-wider">Tipo</th>
               
            </tr>
        </thead>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('tbody', null, []); ?> 
        <tbody>
            <?php $__currentLoopData = $productosVencidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $almacen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="px-6 py-4 whitespace-nowrap text-left"><?php echo e($almacen->producto->codigo); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-left"> <?php echo e($almacen->producto->nombre); ?></td>
                <td class="px-6 py-4 whitespace-nowrap text-left">
                   
                    <?php if($almacen->producto->imagen): ?>
                        <div class="mt-2">
                            <img src="<?php echo e(asset('uploads/' . $almacen->producto->imagen)); ?>" alt="<?php echo e($almacen->producto->nombre); ?>" class="w-16 h-16 object-cover rounded">
                        </div>
                    <?php else: ?>
                        <span class="text-gray-500 block">Sin imagen</span>
                    <?php endif; ?>
                </td>

                <td class="px-6 py-4 whitespace-nowrap text-left">
                    <?php echo e($almacen->sucursal->nombre); ?>

                </td>

                <td class="px-6 py-4 whitespace-nowrap text-left">
                    <?php if($almacen->cantidad <= $almacen->producto->alerta_stock): ?>
                        <span class="text-red-500 font-bold"><?php echo e($almacen->cantidad); ?></span>
                    <?php else: ?>
                        <span class="text-green-500 font-bold"><?php echo e($almacen->cantidad); ?></span>
                    <?php endif; ?>
                </td>

                <td class="px-6 py-4 whitespace-nowrap text-left">
                    <?php if($almacen->producto->tipo == 1): ?>
                        <span class="text-green-500 font-bold">Producto</span>
                    <?php else: ?>
                        <span class="text-red-500 font-bold">Servicio</span>
                    <?php endif; ?>
                </td>

             
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0)): ?>
<?php $component = $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0; ?>
<?php unset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/producto/vencidos.blade.php ENDPATH**/ ?>