

<?php $__env->startSection('titulo','Consultas'); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/3.2.0/css/buttons.dataTables.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/3.0.3/css/responsive.bootstrap5.css">


<?php $__env->stopPush(); ?>

<?php $__env->startSection('contenido'); ?>
    <a href="<?php echo e(route('consultas.create')); ?>">
        <div id="consultas-container"></div>

        <button class="btn btn-success text-white font-bold uppercase">
            Crear
        </button>
    </a>
    <?php if (isset($component)) { $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\DataTable::class, []); ?>
<?php $component->withName('data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('thead', null, []); ?> 
            <thead class=" text-white font-bold">
                <tr class="bg-slate-600  ">
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Código</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Paciente</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Asunto</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Medico</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Consulta</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Proxima Cita</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Estado</th>
                    <th scope="col" class="px-6 py-3 text-left font-medium uppercase tracking-wider" >Acciones</th>
                </tr>
            </thead>
         <?php $__env->endSlot(); ?>

         <?php $__env->slot('tbody', null, []); ?> 
            <tbody>
                <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->id); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->persona->nombre); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->asunto); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->medico->usuario->name); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->fecha_consulta); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap"><?php echo e($consulta->proxima_cita); ?></td>
                    <td class=" px-6 py-4 whitespace-nowrap text-center">
                        <a class="estado" data-id="<?php echo e($consulta->id); ?>" data-estado="<?php echo e($consulta->estado); ?>">
                            <?php if($consulta->estado == 1): ?>
                                <span class="text-green-500 font-bold">Activo</span>
                            <?php else: ?>
                                <span class="text-red-500 font-bold">Inactivo</span>
                            <?php endif; ?>
                        </a>
                    </td>
                    <td class="flex gap-2 justify-center">

                         <form action="<?php echo e(route('consultas.edit',['consulta'=>$consulta->id])); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary font-bold uppercase btn-sm">
                                <i class="fas fa-edit"></i>
                            </button>
                        </form>


                           
                        <button type="button" class="btn btn-warning font-bold uppercase cambiar-estado-btn btn-sm" data-id="<?php echo e($consulta->id); ?>" data-estado="<?php echo e($consulta->estado); ?>" data-info="<?php echo e($consulta->nombre); ?>">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0)): ?>
<?php $component = $__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0; ?>
<?php unset($__componentOriginalc851c13025d4e68615278e773e309a7a21f4cfd0); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
    axios.get('/api/consultas')
        .then(response => {
            console.log(response.data);
            // Renderiza las consultas en tu vista
            renderConsultas(response.data.consultas);
        })
        .catch(error => {
            if (error.response.status === 401) {
                alert('No estás autenticado. Por favor, inicia sesión.');
                window.location.href = '/login';
            } else {
                console.error('Error al cargar las consultas:', error.response.data);
            }
        });
});

function renderConsultas(consultas) {
    const container = document.getElementById('consultas-container');
    container.innerHTML = ''; // Limpia el contenedor

    consultas.forEach(consulta => {
        const div = document.createElement('div');
        div.innerHTML = `
            <p>Consulta ID: ${consulta.id}</p>
            <p>Paciente: ${consulta.persona.nombre}</p>
            <p>Médico: ${consulta.medico.usuario.name}</p>
        `;
        container.appendChild(div);
    });
}

</script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://cdn.datatables.net/responsive/3.0.3/js/dataTables.responsive.js"></script>
<script src="https://cdn.datatables.net/responsive/3.0.3/js/responsive.bootstrap5.js"></script>
<script src="https://cdn.datatables.net/buttons/3.2.0/js/dataTables.buttons.js"></script>





<script src="https://cdn.datatables.net/buttons/3.2.0/js/buttons.html5.min.js">//botones en general</script>
<script src="https://cdn.datatables.net/buttons/3.2.0/js/buttons.print.min.js">//imprimir</script>
<script src="https://cdn.datatables.net/buttons/3.2.0/js/buttons.colVis.min.js">//fltrar columnas</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js">//pdf</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js">//copiar</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js">//excel</script>

<script src=""></script>

<script>
    $(document).ready(function() {
        $('#example').DataTable({
            responsive: true,
            order: [0,'desc'],
            language: {
                url: '/js/i18n/Spanish.json',
                 paginate: {
                     first: `<i class="fa-solid fa-backward"></i>`,
                     previous: `<i class="fa-solid fa-caret-left">`,
                     next: `<i class="fa-solid fa-caret-right"></i>`,
                     last: `<i class="fa-solid fa-forward"></i>`
                 }
            },
            layout: {
                topStart: {

                    buttons: [
                        {
                            extend: 'collection',
                        text: 'Export',
                        buttons: ['copy', 'pdf', 'excel', 'print']
                        },
                        'colvis'
                    ]
                }
            },
            columnDefs: [
                { responsivePriority: 3, targets: 0 },
                { responsivePriority: 1, targets: 1 },
                { responsivePriority: 2, targets: 7 },


            ],
            drawCallback: function() {
                // Esperar un momento para asegurarse de que los botones se hayan cargado
                setTimeout(function() {
                    // Seleccionar los botones de paginación y agregar clases de DaisyUI
                    $('a.paginate_button').addClass('btn btn-sm btn-primary mx-1'); // Todos los botones
                    $('a.paginate_button.current').removeClass('btn-gray-800').addClass('btn btn-sm btn-primary'); // Resaltar la página actual
                }, 100); // Espera 100 ms antes de aplicar las clases
            },
        });
    });
</script>




<?php if(session('success')): ?>
<script>
    const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 1600,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.onmouseenter = Swal.stopTimer;
            toast.onmouseleave = Swal.resumeTimer;
            }
        });
            document.addEventListener('DOMContentLoaded', function() {
                console.log("Evento DOMContentLoaded disparado");
                Toast.fire({ icon: "success",
                title: "<?php echo e(session('success')); ?>"
                });
        });
</script>
<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const changeStateButtons = document.querySelectorAll('.cambiar-estado-btn');

        changeStateButtons.forEach(button => {
            button.addEventListener('click', function () {
                const Id = this.getAttribute('data-id');
                let estado = this.getAttribute('data-estado'); // Tomamos el estado actual del data-estado
                const nombre = this.getAttribute('data-info'); // Este es informacion

                Swal.fire({
                    title: "¿Estás seguro?",
                    text: "¡Deseas cambiar el estado de " + nombre + "!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Sí, cambiar estado",
                    cancelButtonText: "Cancelar"
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Realizar la solicitud Ajax para cambiar el estado
                        $.ajax({
                            url: '/consulta/' + Id + '/cambiar-estado',
                            method: 'POST',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>',
                                estado: estado == 1 ? 2 : 1, // Cambiar entre activo (1) y inactivo (2)
                            },
                            success: function (response) {
                                if (response.success) {
                                    // Después de cambiar el estado en la base de datos, actualizamos el frontend
                                    estado = estado == 1 ? 2: 1; // Actualizamos la variable de estado
                                    const estadoText = estado == 1 ? 'Activo' : 'Inactivo';
                                    const estadoColor = estado == 1 ? 'text-green-500' : 'text-red-500';

                                    // Actualizamos la columna de estado en el frontend
                                    const estadoElement = $('a[data-id="' + Id + '"]');
                                    estadoElement.html('<span class="' + estadoColor + ' font-bold">' + estadoText + '</span>');

                                    // Actualizamos el valor del estado en el data-estado para el siguiente clic
                                    estadoElement.data('estado', estado);

                                    // Recargamos la página después de actualizar el estado
                                    location.reload();
                                } else {
                                    alert('Error al cambiar el estado');
                                }
                            },
                            error: function () {
                                alert('Ocurrió un error en la solicitud.');
                            }
                        });
                    }
                });
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/consulta/index.blade.php ENDPATH**/ ?>