<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="/Logos/favicon-32x32.png" type="image/x-icon">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('js/app.js')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Farmacias Antigua Guatemala</title>
</head>
<body class="bg-[#175858] flex items-center justify-center h-full">
   <?php echo $__env->yieldContent('contenido'); ?> 

</body>
</html>
<?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/layouts/login.blade.php ENDPATH**/ ?>