

<?php $__env->startSection('titulo', 'Detalle de Lotes en Inventario'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="card">
    <h2 class="text-xl font-bold mb-4">Lotes Originales</h2>
    <div class="overflow-x-auto max-h-[500px]">
        <table class="table table-md table-pin-rows table-pin-cols">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Número de Lote</th>
                    <th>Producto</th>
                    <th>Cantidad Original</th>
                    <th>Precio de compra</th>
                    <th>Fecha de Vencimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php $iteracion = 0; ?>
                <?php $__currentLoopData = $lotesOriginales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $fechaActual = \Carbon\Carbon::now(); // Fecha actual
                        $fechaCaducidad = \Carbon\Carbon::parse($lote->fecha_vencimiento); // Convierte la fecha de caducidad a Carbon
                        $diferenciaDias = $fechaActual->diffInDays($fechaCaducidad, false); // Diferencia en días (negativo si ya caducó)
                ?>
                <?php $iteracion++; ?>
                <tr>
                    <th><?php echo e($iteracion); ?></th>
                    <td><?php echo e($lote->numero_lote); ?></td>
                    <td><?php echo e($lote->producto->nombre); ?></td>
                    <td><?php echo e($lote->cantidad); ?></td>
                    <td><?php echo e($lote->precio_compra); ?></td>
                    
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if($diferenciaDias < 0): ?>
                            <span class="text-red-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                     (Caducado)
                            </span>
                        <?php elseif($diferenciaDias <= 30): ?>
                            <span class= "text-yellow-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                    (Próximo a caducar)
                            </span>
                        <?php else: ?>
                            <span class="text-green-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                    (Vigente)
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <h2 class="text-xl font-bold mt-8 mb-4">Lotes Disponibles en Inventario</h2>
    <div class="overflow-x-auto max-h-[500px]">
        <table class="table table-md table-pin-rows table-pin-cols">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Número de Lote</th>
                    <th>Producto</th>
                    <th>Bodega</th>
                    <th>Cantidad Disponible</th>
                    <th>Precio de compra</th>
                    <th>Fecha de Vencimiento</th>
                </tr>
            </thead>
            <tbody>
                <?php $iteracion = 0; ?>
                <?php $__currentLoopData = $lotesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                     $fechaActual = \Carbon\Carbon::now(); // Fecha actual
                        $fechaCaducidad = \Carbon\Carbon::parse($inventario->lote->fecha_vencimiento); // Convierte la fecha de caducidad a Carbon
                        $diferenciaDias = $fechaActual->diffInDays($fechaCaducidad, false); // Diferencia en días (negativo si ya caducó)
                ?>
                <?php $iteracion++; ?>
                <tr>
                    <th><?php echo e($iteracion); ?></th>
                    <td><?php echo e($inventario->lote->numero_lote); ?></td>
                    <td><?php echo e($inventario->producto->nombre); ?></td>
                    <td><?php echo e($inventario->bodega->nombre); ?></td>
                    <td><?php echo e($inventario->cantidad); ?></td>
                    <td><?php echo e($inventario->lote->precio_compra); ?></td>
                    
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php if($diferenciaDias < 0): ?>
                            <span class="text-red-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                     (Caducado)
                            </span>
                        <?php elseif($diferenciaDias <= 30): ?>
                            <span class= "text-yellow-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                    (Próximo a caducar)
                            </span>
                        <?php else: ?>
                            <span class="text-green-500 font-bold">
                                <?php echo e($fechaCaducidad->format('d/m/Y')); ?>

                                    (Vigente)
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\John\Documents\Antigua\farmacia\resources\views/Inventario/show.blade.php ENDPATH**/ ?>