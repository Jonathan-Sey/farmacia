function myFunction() {
    console.log('Función importada sin módulos');
}

window.myFunction = myFunction; // Exponerlo globalmente